package tech.tylor.w9d2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class W9d2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
