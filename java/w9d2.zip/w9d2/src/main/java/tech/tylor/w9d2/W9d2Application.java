package tech.tylor.w9d2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class W9d2Application {

	public static void main(String[] args) {
		SpringApplication.run(W9d2Application.class, args);
	}

}
